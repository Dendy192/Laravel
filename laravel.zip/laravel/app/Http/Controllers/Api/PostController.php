<?php

namespace App\Http\Controllers\Api\PostsController;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Post;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;


class PostController extends Controller
{
    public function create(Request $request){
 
        $post = new Post;
        $post->post_id = $request->id;
        $post->judul = $request->judul;
        $post->isi= $request->isi;
        $post->username = $request->username;
        $post->save();

        return response()->json([
            'success' => true,
            'posting' => $post,
            'message' => 'Postting added'
        ]);
    }

    public function update(reqeust $request){
        $post = Post::find($request->id);
        $post->post = $request->post;
        $post->update();

        return response()->json([
            'succes' => true,
            'message' => 'article updated'
        ]);
    }

    public function delete (request $request){
        $post = Post::find($request->id);
        $post->delte();
        return response()->json([
            'success' => true,
            'message' => 'comment deleted'
        ]);
    
    }
}
